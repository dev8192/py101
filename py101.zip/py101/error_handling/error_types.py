
def test1():
    dict1 = {
        "key1": "val1",
    }
    try:
        print(dict1["key2"])
    except KeyError:
        print('KeyError')
    print('done')

def test1():
    try:
        print(var1)
    except NameError:
        print('NameError')
    print('done')

def test():
    try:
        fruits1 = ('apple', 'orange', 'kiwi') # tuple
        fruits1[0] = 'mango'
        print(fruits1)
    except TypeError:
        print('TypeError')
    print('done')

def test():
    try:
        fruits = ['pineapple', 'orange', 'kiwi'] 
        print(fruits[5])
    except IndexError:
        print('IndexError')
    print('done')

test()

