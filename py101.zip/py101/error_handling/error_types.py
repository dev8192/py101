
def test1():
    dict1 = {
        "key1": "val1",
    }
    try:
        print(dict1["key2"])
    except KeyError:
        print('KeyError')
    print('done')

def test():
    try:
        print(var1)
    except NameError:
        print('NameError')
    print('done')

test()
