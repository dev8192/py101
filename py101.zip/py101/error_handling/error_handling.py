
def test1():
    dict1 = {
        "key1": "val1",
    }
    # print(dict1["key2"])
    try:
        print(dict1["key2"])
    except:
        print('oops')
    print('done')

def test():
    dict1 = {
        "key1": "val1",
    }
    try:
        # print(dict1["key2"])
        print(dict2)
        # print(5/0)
    except KeyError:
        print('KeyError')
    except NameError:
        print('NameError')
    except ZeroDivisionError:
        print('ZeroDivisionError')
    except:
        print('Some other error')
    print('done')

test()
