py101 is a course for beginner programmers (with 4 months of programming experience). We use Electum as a context for this course. An experience programmer (me) simplifies complex concepts and makes them accessible to students of all levels.
The course objectives:
-- get understanding of common algorithms and data structures,
-- develop good programming skills (in Python),
-- put this knowledge and skills into practice (by doing exercises based on the source code or real projects and libraries).
