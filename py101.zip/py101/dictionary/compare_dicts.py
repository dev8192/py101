def compare_dicts(d1, d2):
    for key in d1:
        if key in d2:
            if d1[key] != d2[key]:
                return False
        else:
            return False
    for key in d2:
        if key in d1:
            if d1[key] != d2[key]:
                return False
        else:
            return False
    return True


print(compare_dicts(
    {2: 5, 6: 9, 8: 11},
    {2: 5, 6: 9, 8: 11},
)) # True
print(compare_dicts(
    {2: 5, 8: 11, 6: 9},
    {2: 5, 6: 9, 8: 11},
)) # True
print(compare_dicts(
    {2: 5, 6: 5},
    {2: 5, 6: 10},
)) # False
print(compare_dicts(
    {2: 5},
    {2: 5, 6: 10},
)) # False
