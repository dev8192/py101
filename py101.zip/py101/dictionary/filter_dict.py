def filter_dict(d):
    result={}
    for key in d:
        if key%2==0 and d[key]%2==1:
            result [key]=d[key]
    return result
            





original = {
    1: 3, 
    2: 5, 
    4: 8, 
    6: 9, 
    7: 2, 
    8: 11
}
result = filter_dict(original)
print(result) # {2: 5, 6: 9, 8: 11}
