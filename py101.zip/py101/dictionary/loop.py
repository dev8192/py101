'''
    Dictionary + loop
'''

dict1 = {
    "Alice": 5,
    "Bob": 4,
    "Charlie": 5,
    "David": 3,
    "Eve": 4
}

# for key in dict1:
#     print(key)

# for key in dict1.keys():
#     print(key)

# for value in dict1.values():
#     print(value)

# for item in dict1.items():
#     print(item)

for key, val in dict1.items():
    print(key, val)


