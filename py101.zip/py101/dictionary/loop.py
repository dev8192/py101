'''
    Dictionary + loop
'''

dict1 = {
    1: 3, 
    2: 5, 
    4: 8, 
    6: 9, 
    7: 2, 
    8: 11
}
for key in dict1:
    print(key, dict1[key])

