def group_by_grades(grades):
    result = {}
    for name, grade in grades.items():
        if grade in result:
            result[grade].append(name)
        else:
            result[grade] = [name]
    return result

print(group_by_grades({
    "Alice": 5,
    "Bob": 4,
    "Charlie": 5,
    "David": 3,
    "Eve": 4
}))
'''
{
  5: ['Alice', 'Charlie'],
  4: ['Bob', 'Eve'],
  3: ['David']
}
'''