'''
    This file shows how to use a dictionary
'''

def test1():
    dict1 = {
        "key1": "val1",
        "key2": "val2",
        "key3": "val3",
    }
    print(dict1)

def test1():
    dict1 = {
        "key1": "val1",
        "key2": "val2",
        "key3": "val3",
    }
    print(dict1["key1"])

def test1():
    dict1 = {
        "key1": "val1",
        "key2": "val2",
        "key3": "val3",
    }
    print(dict1)
    dict1["key4"] = "val4"
    print(dict1)

def test1():
    dict1 = {
        "key1": "val1",
    }
    try:
        print(dict1["key5"])
    except:
        print('oops')

def test():
    dict1 = {
        "key1": "val1",
        "key2": "val2",
        "key3": "val3",
    }
    print(dict1)
    del dict1["key1"]
    print(dict1)
    del dict1["key2"]
    print(dict1)
    del dict1["key3"]
    print(dict1)

test()
