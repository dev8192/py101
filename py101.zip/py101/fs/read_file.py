'''
How to read files
'''

def test1():
    file_name = 'hello.txt'
    with open(file_name, 'r', encoding='utf-8') as f:
        s = f.read()
        print(s)

def test1():
    file_name = 'hello.txt'
    with open(file_name, 'r', encoding='utf-8') as f:
        s = f.read()
        result = 0
        for item in s.split('\n'):
            try:
                result += int(item)
            except:
                pass
        print(result)

def test():
    file_name = 'hello.txt'
    with open(file_name, 'r', encoding='utf-8') as f:
        s = f.read()
        result = 0
        try:
            for item in s.split('\n'):
                result += int(item)
        except:
            pass
        print(result)

test()
