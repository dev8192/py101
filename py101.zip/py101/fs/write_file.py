
def test():
    numbers = [-5, 3, 8, 12, -10, 16]
    sum = 0 

    for item in numbers:
        if item > 0 and item % 2 == 0:
            sum += item
    print(sum)

    with open('hello.txt', 'w', encoding='utf-8') as file:
        file.write(str(sum))

test()
