def final_score(scores):
    max_score = max(scores)
    min_score = min(scores)
    result = 0
    if len(scores) == 2:
        return 0.0
    for num in scores:
        if num == max_score or num == min_score:
            continue
        result += num
    return result / (len(scores) - 2)

print(final_score([8.5, 9.0, 7.0, 10.0, 9.5])) # 9.0
print(final_score([10.0, 5.0])) # 0.0
