
def print_average(data):
    result = []
    for item in data:
        item = item.strip()
        if item.isdigit():
            result.append(int(item))
    average = sum(result) / len(result)
    print(average)

data = [" 1200 ", "450руб", "3000", "бесплатно", " 150 "]
print_average(data)
