def most_frequent_odd_char(str1):
    if len(str1) < 2:
        return None
    str2 = ''
    for i in range(len(str1)):
        if i % 2 == 1:
            str2 += str1[i]
    dict1 = {}
    for j in str2:
        if j in dict1:
            dict1[j] += 1
        else:
            dict1[j] = 1
    result = (str1[1], dict1[str1[1]])
    for key in dict1:
        if dict1[key] > result[1]:
            result = (key, dict1[key])
    return result[0]
  
print(most_frequent_odd_char("abacabad")) # 'b'
print(most_frequent_odd_char("xyz")) # 'y'
print(most_frequent_odd_char("a")) # None
