def test():
    list1 = [
        "snake_case",
        "camelCase",
        "kebab-case",
    ]
    for item in list1:
        print(item)

test()
