def test1():
    list1 = [
        "snake_case",
        "camelCase",
        "kebab-case",
    ]
    for item in list1:
        print(item)

def test1():
    list1 = [
        "snake_case",
        "camelCase",
        "kebab-case",
    ]
    for item in list1:
        print(len(item))

def test1():
    print('hello')
    print('hello')
    print('hello')
    print('hello')
    print('hello')

def test1():
    for i in range(3):
        print('hello')

def test():
    for i in range(3, 10, 2):
        print(i)

test()
