def find_peaks(arr):
    result = []
    if arr[0] > arr[1]:
        result.append(arr[0])
    for i in range(1, len(arr) - 1):
        if arr[i] > (arr[i-1] + arr[i+1]):
            result.append(arr[i])
    if arr[-1] > arr[-2]:
        result.append(arr[-1])
    return result
print(find_peaks([3, 8, 2, 7, 1]))
