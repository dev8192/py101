def calculate_bill(menu_prices, customer_order):
    result = 0
    for item in customer_order:
        if item in menu_prices:
            result += menu_prices[item]
    return result    

menu_prices = {
    "Pizza": 500,
    "Burger": 300,
    "Fries": 150,
    "Cola": 100
}
customer_order = ["Pizza", "Cola", "Pizza", "Ice Cream", "Fries", "Python"]
total = calculate_bill(menu_prices, customer_order)
print(f"Total bill: {total}")
# Ожидаемый вывод: 1250 (500 + 100 + 500 + 0 + 150)
