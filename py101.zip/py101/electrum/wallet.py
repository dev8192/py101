"""
Electrum mechanics:
(1) user accepts terms of use           electrum\gui\messages.py
(2) user clicks Next                    electrum\gui\qt\wizard\server_connect.py
(3) user is presented with a seed       electrum\simple_config.py

Seed example:
program actual shadow ecology cable tobacco catalog feed coral typical snake erase


"""

# electrum\gui\messages.py
MSG_TERMS_OF_USE = (
"""1. Electrum is distributed under the MIT licence
"""
)

# electrum\gui\qt\wizard\server_connect.py
class WCWelcome(WizardComponent):
    def __init__(self, parent, wizard):
        self.second_help_label.setText(
            _("If you are unsure what these options are, leave them unchecked.")
        )

# electrum\simple_config.py
class SimpleConfig(Logger):
    def get_fallback_wallet_path(self):
        return os.path.join(self.get_datadir_wallet_path(), "default_wallet")


