def find_longest_word(words):
    max_len = 0
    result = ''
    for word in words:
        if len(word) > max_len:
            max_len = len(word)
            result = word
    return result

print(find_longest_word([
    "cat", "dog", "elephant", "ant"
]))  # elephant

print(find_longest_word([
    "apple", "pear", "grape"
]))  # apple

print(find_longest_word([]))  # ''