
def test1():
    fruits1 = ['apple', 'orange', 'kiwi'] # list
    fruits2 = ('apple', 'orange', 'kiwi') # tuple
    print(fruits1)
    print(fruits2)

'''
TypeError: 'tuple' object does not support item assignment
'''
def test():
    fruits1 = ['apple', 'orange', 'kiwi'] # list
    fruits2 = ('apple', 'orange', 'kiwi') # tuple
    fruits1[0] = 'mango'
    print(fruits1)
    # fruits2[0] = 'mango'
    print(fruits2)

test()
