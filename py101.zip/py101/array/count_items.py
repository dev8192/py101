def count_items(items):
    result = {}
    for item in items:
        if item in result:
            result[item] += 1
        else:
            result[item] = 1
    return result

print(count_items([
    "банан",
    "яблоко",
    "банан",
    "апельсин",
    "яблоко",
    "банан"
])) # {'банан': 3, 'яблоко': 2, 'апельсин': 1}
print(count_items([])) # {}
