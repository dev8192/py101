'''
Reimplement builtin sum()
'''

def add(arr):
    res = 0
    for item in arr:
        res += item
    return res

print(add([13, 5, 2]))
print(add([13.25, 5.5, 1.25]))
    