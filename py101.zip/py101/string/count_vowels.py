def count_vowels(word):
    letters = ('a', 'e', 'i', 'o', 'u', 'y')
    result = []
    for ch in word:
        if ch in letters:
            result.append(ch)

    return result


print(count_vowels("Hello World"))  # 3 (e, o, o)
print(count_vowels("Python"))       # 2 (o, y)
print(count_vowels("bcdfg"))        # 0