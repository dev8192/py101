

def analyze_logs(logs):
    result = {
        'successful': 0,
        'errors_4xx': 0,
        'errors_5xx': 0,
        'total_requests': len(logs)
    }
    elements = {}
    for item in logs:
        arr = item.split()
        ip = arr[0]
        status_code = arr[7]
        if status_code.startswith('2'):
            result['successful'] += 1
        elif status_code.startswith('4'):
            result['errors_4xx'] += 1
        elif status_code.startswith('5'):
            result['errors_5xx'] += 1
        if ip in elements:
            elements[ip] += 1
        else:
            elements[ip] = 1
    result['top_ip'] = max(elements)
    return result

logs = [
    '192.168.1.1 - - [01/Jan/2026] "GET /home HTTP/1.1" 200 1234',
    '192.168.1.1 - - [01/Jan/2026] "GET /api HTTP/1.1" 200 567',
    '10.0.0.1 - - [01/Jan/2026] "GET /admin HTTP/1.1" 404 0',
    '192.168.1.1 - - [01/Jan/2026] "POST /login HTTP/1.1" 500 0'
]

result = analyze_logs(logs)
expected_result = {
    'total_requests': 4,
    'successful': 2,
    'errors_4xx': 1,
    'errors_5xx': 1,
    'top_ip': '192.168.1.1'
}

def compare_dicts(dict1, dict2):
    for key in dict1:
        if dict1[key] != dict2[key]:
            return False
    return True
print(compare_dicts(expected_result, result))

