
name = "John"
print("hello " + name)
print(f"hello {name}")
