def count_chars(text):
    text = text.lower()
    result = {}
    for ch in text:
        if ch == " ":
            continue
        if ch in result:
            result[ch] += 1
        else:
            result[ch] = 1
    return result
    
input_text = 'Hello World'
result = count_chars(input_text)
# {'h': 1, 'e': 1, 'l': 3, 'o': 2, 'w': 1, 'r': 1, 'd': 1}
print(result)
