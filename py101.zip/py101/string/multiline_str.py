
def test1():
    str1 = '''
        snake_case
        camelCase
        kebab-case
    '''
    print(str1)

def test():
    list1 = [
        "snake_case",
        "camelCase",
        "kebab-case",
    ]
    # print(list1)
    print(list1[0])
    print(list1[1])
    print(list1[2])

def test3():
    list1 = [
        "snake_case",
        "camelCase",
        "kebab-case",
    ]
    for item in list1:
        print(item)

test()
