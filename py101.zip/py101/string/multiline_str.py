
def test1():
    str1 = '''
        snake_case
        camelCase
        kebab-case
    '''
    print(str1)

def test2():
    list1 = [
        "snake_case",
        "camelCase",
        "kebab-case",
    ]
    print(list1)

def test():
    list1 = [
        "snake_case",
        "camelCase",
        "kebab-case",
    ]
    for item in list1:
        print(item)

test()
