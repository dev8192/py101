def is_valid_password(password):
    min_len = 8
    if len(password) < min_len:
        return False
    ch_zero = 48
    ch_nine = 57
    for ch in password:
        char_code = ord(ch)
        if char_code >= ch_zero and char_code <= ch_nine:
            return True
    return False

print(is_valid_password("Python3")) # False
print(is_valid_password("LearningCode")) # False
print(is_valid_password("SecurePass2024")) # True
