def test():
    print(len('hello'))
test()