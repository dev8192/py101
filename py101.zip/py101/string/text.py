def word_frequency(text):
    results = {}
    text = text.lower()
    text = text.split()
    
    for word in text:
        if word in results:
            results[word] += 1
        else:
            results[word] = 1
    return results  
        

print(word_frequency("Hello world hello"))
#{'hello': 2, 'world': 1}