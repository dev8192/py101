def char_frequency(text):
    result = {}
    for ch in text:
        if ch in result:
            result[ch] += 1
        else:
            result[ch] = 1
    return result

text = "apple pie"
result = char_frequency(text)
# {'a': 1, 'p': 3, 'l': 1, 'e': 2, ' ': 1, 'i': 1}
print(result) 
