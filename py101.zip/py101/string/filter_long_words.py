def filter_long_words(sentence, limit):
    words = []
    for word in sentence.split(' '):
        if len(word) > limit:
            words.append(word)
    return words 


sentence = "Python это прекрасный язык программирования для начинающих"
limit = 6
result = filter_long_words(sentence, limit)
print(result) 
# Ожидаемый вывод: ['прекрасный', 'программирования', 'начинающих']
