print(True)
print(False)
print(5 > 0)
print(15 < 10)
