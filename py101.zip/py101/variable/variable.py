
var1 = 123 # var1 is global
print(var1)

def test():
    print(var1)
    var2 = 456 # var2 is local
    print(var2)

try:
    print(var2)
except:
    print('cannot access a local variable')
test()
print('done')
