products = [
    ("Яблоки", 120),
    ("Бананы", 80),
    ("Манго", 250),
    ("Киви", 150)
]

def analyze_sales(products):
    most_expensive = products[0]
    for product in products[1:]:
        if product[1] > most_expensive[1]:
            most_expensive = product
    average = 0
    for product in products:
        average += product[1]
    average = average / len(products)
    return most_expensive[0], average

most_expensive, average_price = analyze_sales(products)
print(f"Самый дорогой товар: {most_expensive}")
print(f"Средняя цена: {average_price}")
# Самый дорогой товар: Манго
# Средняя цена: 150.0
