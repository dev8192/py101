class Garage():
    def __init__(self):
        self.cars = []
    def add_car(self, car):
        self.cars.append(car)
    def find_cars_by_brand(self, brand):
        result = []
        for car in self.cars:
            if car['brand'] == brand:
                result.append(car)
        return result

garage = Garage()    
garage.add_car({'brand': 'Toyota', 'model': 'Camry', 'year': 2018})
garage.add_car({'brand': 'Ford', 'model': 'Mustang', 'year': 2020})
garage.add_car({'brand': 'Toyota', 'model': 'Corolla', 'year': 2019})

print(garage.find_cars_by_brand('Toyota'))
