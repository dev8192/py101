
class Parent1:
    def __init__(self, key2 = None):
        self.key2 = key2
        print('Parent1 constructor')
    def print_key2(self):
        print('Parent1', self.key2)
    def print_parent1(self):
        print('print_parent1')

class Parent2:
    def __init__(self, key3 = None):
        self.key3 = key3
        print('Parent2 constructor')
    def print_key3(self):
        print('Parent2', self.key3)
    def print_parent2(self):
        print('print_parent2')

class Child(Parent1, Parent2):
    def __init__(self, key1, key2, key3):
        print('Child constructor')
        Parent1.__init__(key2)
        Parent2.__init__(key3)
        self.key1 = key1
    def print_key1(self):
        print('Child', self.key1)

child = Child('val1', 'val2', 'val3')
child.print_key1()
child.print_key2()
child.print_key3()
child.print_parent1()
child.print_parent2()
