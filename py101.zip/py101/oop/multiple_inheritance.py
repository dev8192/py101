
class Parent1:
    def __init__(self, key2 = None):
        self.key2 = key2
        print('Parent1')
    def print_key2(self):
        print('Parent1', self.key2)
    def print_parent1(self):
        print('print_parent1')

class Parent2:
    def __init__(self, key2 = None):
        self.key2 = key2
        print('Parent2')
    def print_key2(self):
        print('Parent2', self.key2)
    def print_parent2(self):
        print('print_parent2')

# class Child(Parent1, Parent2):
class Child(Parent2, Parent1):
    def __init__(self, key1, key2):
        print('Child')
        super().__init__(key2)
        self.key1 = key1
    def print_key1(self):
        print('Child', self.key1)

child = Child('val1', 'val2')
child.print_key1()
child.print_key2()
child.print_parent1()
child.print_parent2()
