
class Animal:
    def __init__(self, name):
        self.name = name

    def speak(self):
        return f"{self.name} makes a sound"

class Dog(Animal):
    def __init__(self, name, breed):
        super().__init__(name)
        self.breed = breed

    def speak(self):
        return f"{self.name} the {self.breed} says: bark"

    def fetch(self, item):
        return f"{self.name} fetched {item}!"

class Cat(Animal):
    def speak(self):
        return f"{self.name} says: meow"

buddy = Dog("Buddy", "Golden Retriever")
whiskers = Cat("Whiskers")

print(buddy.speak())
print(whiskers.speak())
print(buddy.fetch("ball"))
