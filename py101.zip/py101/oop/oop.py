class Person:
    def __init__(self, first_name, last_name, age):
        self.first_name = first_name
        self.last_name = last_name
        self.age = age
    
    def info(self):
        return f"{self.first_name} {self.last_name} ({self.age})"

alice = Person("Alice", "Smith", 28)
print(alice.info())

bob = Person("Bob", "Johnson", 35)
print(bob.info())
