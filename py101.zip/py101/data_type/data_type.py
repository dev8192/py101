
int_example = 123
print(type(int_example))

float_example = 123.5
print(type(float_example))

str_example = 'hello'
print(type(str_example))

bool_example = True
print(type(bool_example))

list_example = []
print(type(list_example))

dict_example = {}
print(type(dict_example))

tuple_example = ()
print(type(tuple_example))

set_example = {5, 10, 15}
print(type(set_example))

NoneType_example = None
print(type(NoneType_example))
