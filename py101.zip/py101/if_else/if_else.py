import random

var1 = random.randint(-5, 5)
if var1 > 0:
    print(f'{var1} is greater than 0')
elif var1 < 0:
    print(f'{var1} is less than 0')
else:
    print('var1 is equal to 0')
