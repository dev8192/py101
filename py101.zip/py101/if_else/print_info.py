
def print_info(data):
    result = []
    count = 0
    for item in data:
        if item['quantity'] > 0:
            result.append(item)
        if item['category'] == 'Electronics':
            count += item["quantity"] 
    print(result)
    print(count)

data = [
    {"name": "Laptop", "category": "Electronics", "quantity": 10},
    {"name": "Mouse", "category": "Electronics", "quantity": 0},
    {"name": "Chair", "category": "Furniture", "quantity": 5},
    {"name": "Desk", "category": "Furniture", "quantity": 2},
    {"name": "Monitor", "category": "Electronics", "quantity": 7}
]
print_info(data)
