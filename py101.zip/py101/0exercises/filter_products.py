def filter_products(products, max_price):
    result = []
    for product in products:
        if product[1] < max_price:
            result.append(product[0])
    return result

catalog = [
    ("Laptop", 1200),
    ("Mouse", 25),
    ("Keyboard", 80),
    ("Monitor", 300),
    ("USB Drive", 15)
]

def main1():
    print(len(catalog))

def main2():
    budget = 100
    affordable_items = filter_products(catalog, budget)
    print(affordable_items) # ['Keyboard', 'Mouse', 'USB Drive']

def main3():
    print(catalog[0])
    print(catalog[1])
    print(catalog[2])

def main4():
    print(catalog[0])
    print(catalog[-1])

def main5():
    for item in catalog:
        print(item[0])

def main():
    ebx = 0
    while ebx < len(catalog):
        print(catalog[ebx])
        ebx += 1

main()
