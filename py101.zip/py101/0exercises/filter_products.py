def filter_products(products, max_price):
    result = []
    for product in products:
        if product[1] < max_price:
            result.append(product[0])
    return result

catalog = [
    ("Laptop", 1200),
    ("Mouse", 25),
    ("Keyboard", 80),
    ("Monitor", 300),
    ("USB Drive", 15)
]
budget = 100
affordable_items = filter_products(catalog, budget)
# Ожидаемый результат: ['Keyboard', 'Mouse', 'USB Drive']
print(affordable_items)
