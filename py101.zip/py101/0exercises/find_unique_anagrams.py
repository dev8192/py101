def find_unique_anagrams(arr):
    orig_words = {}
    dict1 = {}
    for word in arr:
        key = "".join(sorted([*word.lower()]))
        orig_words[key] = word
        if key in dict1:
            dict1[key] += 1
        else:
            dict1[key] = 1
        print(word, dict1)
    temp = []
    for key,val in dict1.items():
        if val == 1:
            temp.append(orig_words[key])
    return temp

words = ["Lemon", "melon", "Apple", "Banana", "cat", "act", "Tab"]
result = find_unique_anagrams(words)
# ["Apple", "Banana", "Tab"]
# "Lemon" и "melon" — анаграммы (исключаем оба)
# "cat" и "act" — анаграммы (исключаем оба)
print(result)
