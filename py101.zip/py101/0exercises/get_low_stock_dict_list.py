def get_low_stock(inventory, threshold):
    result = []
    for item in inventory:
        if item["qty"] < threshold:
            result.append(item["name"])
    return result

stocks = [
    {"name": "яблоки", "qty": 50},
    {"name": "бананы", "qty": 12},
    {"name": "апельсины", "qty": 8},
    {"name": "груши", "qty": 25},
    {"name": "киви", "qty": 3}
]           
# stocks["киви"]=16
# stocks["манго"]=14
# Ищем товары, которых осталось меньше 15 штук
result = get_low_stock(stocks, 15)

print(result) 
# Ожидаемый вывод: ['апельсины', 'бананы', 'киви']
