def filter_and_upper(text, min_length):
    res = []
    text = text.upper().split()
    for word in text:
        print(word)
        if len(word) >= min_length:
            res.append(word)
    return res

sentence = "Python это мощный язык программирования для решения сложных задач"
length = 5
result = filter_and_upper(sentence, length)
# Ожидаемый результат:
# ['PYTHON', 'МОЩНЫЙ', 'ПРОГРАММИРОВАНИЯ', 'РЕШЕНИЯ', 'СЛОЖНЫХ', 'ЗАДАЧ']
print(result)
