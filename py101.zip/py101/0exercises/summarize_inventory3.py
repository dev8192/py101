def summarize_inventory(items):
    result = {}
    for item in items:
        key = list(item.keys())[0]
        # value = list(item.values())[0] 
        value = item[key]
        if value is None:
            continue
        if key in result:
            result[key] += value
        else: 
            result[key] = value
            

    return result

data = [
    {"apple": 10}, {"banana": None}, 
    {"apple": 3}, {"pear": 8}, 
    {"banana": -2}
]
# Ожидаемый результат: {'apple': 13, 'banana': 3, 'pear': 8}
result = summarize_inventory(data)
print(result)