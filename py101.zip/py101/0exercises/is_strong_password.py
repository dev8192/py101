def is_strong_password(password):
    if len (password) < 8:
        return False

pwd1 = "mysecret1"
result1 = is_strong_password(pwd1)
print(f"Пароль '{pwd1}': {result1}")  # True (длина 9, есть цифра)

pwd2 = "short1"
result2 = is_strong_password(pwd2)
print(f"Пароль '{pwd2}': {result2}")  # False (длина меньше 8)

pwd3 = "longpassword"
result3 = is_strong_password(pwd3)
print(f"Пароль '{pwd3}': {result3}")  # False (нет цифр)

pwd4 = ""
result4 = is_strong_password(pwd4)
print(f"Пароль '{pwd4}': {result4}")  # False
