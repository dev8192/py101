def get_total_value(stock, min_price): 
    result = 0 
    for item in stock:
        if item["price"] >= min_price:
            result += item["price"] * item["quantity"]
    return result 

items = [
    {"name": "Laptop", "price": 1000, "quantity": 3},
    {"name": "Mouse", "price": 25, "quantity": 10},
    {"name": "Monitor", "price": 200, "quantity": 5},
    {"name": "USB-Cable", "price": 10, "quantity": 20}
]
result = get_total_value(items, 100)
print(result) 
# Ожидаемый вывод: 4000 
# (Считаем Laptop: 1000*3 + Monitor: 200*5. Остальное игнорируем.)
