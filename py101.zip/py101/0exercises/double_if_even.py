def double_if_even(number):
    if number % 2 == 0:
        return number * 2
    return number

result1 = double_if_even(10)
print(result1)  # 20

result2 = double_if_even(7)
print(result2)  # 7

result3 = double_if_even(-4)
print(result3)  # -8

result4 = double_if_even(0)
print(result4)  # 0