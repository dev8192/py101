def count_vowels(text):
    text = text.lower()
    counter = 0
    for ch in text:
        # if ch == 'a' or ch == 'e' or ch == 'i' or ch == 'o' or ch == 'u':
        if ch in 'aeiou':
            counter += 1
    return counter

def main1():
    print('*** main1 ***')
    result = count_vowels('Hello World')
    print(result)  # 3

def main():
    print('*** main1 ***')
    print(123, 'hello', [5, 10])

main()
