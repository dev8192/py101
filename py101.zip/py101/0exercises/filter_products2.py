def filter_products(products, min_rating, max_price):
    result = []
    for product in products:
        if product["price"] <= 60000 and product["rating"] >= 4.5:
            result.append(product["name"])

    return result

data = [
    {"name": "Smartphone", "price": 50000, "rating": 4.8},
    {"name": "Mouse", "price": 1200, "rating": 4.2},
    {"name": "Laptop", "price": 90000, "rating": 4.5},
    {"name": "Monitor", "price": 15000, "rating": 3.9},
    {"name": "Keyboard", "price": 2500, "rating": 4.6}
]

# Нужно найти товары с рейтингом от 4.5 и ценой до 60 000 руб.
result = filter_products(data, 4.5, 60000)
print(result) 
# Ожидаемый вывод: ['Keyboard', 'Smartphone']
