def mask_card_number(card_number):
    numbers = card_number[-4:]
    return "**** **** **** " + numbers 

card = "1234567812345678"
masked = mask_card_number(card)
print(masked)
# Ожидаемый вывод: "**** **** **** 5678"
