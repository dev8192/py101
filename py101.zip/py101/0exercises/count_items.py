def count_items(items):
    result = {}
    for item in items:
        if item in result:
            result[item] += 1
        else:
            result[item] = 1
    return result

shopping_list = ["банан", "яблоко", "банан", "апельсин", "яблоко", "банан"]
inventory = count_items(shopping_list)
# Ожидаемый вывод: {'банан': 3, 'яблоко': 2, 'апельсин': 1}
print(inventory)
print(count_items([])) # Ожидаемый вывод: {}
