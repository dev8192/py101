def sum_even_numbers(numbers):
    result = 0
    for num in numbers:
        if num % 2 == 0:
            result += num
    return result

result = sum_even_numbers([1, 2, 3, 4, 5, 6])
print(result)  # 12
