def analyze_weather(temperatures, min_temp, max_temp):
    result = {}
    result["average"] = sum(temperatures) / len(temperatures)
    result["comfortable"] = []
    for i in range(len(temperatures)):
        if temperatures[i] >= min_temp and temperatures[i] <= max_temp:
            result["comfortable"].append(i)
    return result

weekly_data = [18, 22, 25, 15, 21, 28, 19]
report = analyze_weather(weekly_data, 20, 23)
print(report)
# Ожидаемый вывод:
# {'comfortable': [1, 4], 'average': 21.1}
