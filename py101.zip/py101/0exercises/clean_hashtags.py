def clean_hashtags(text):
    text = text.lower()
    set1 = set()
    result = []
    tags = text.split(" ")
    for tag in tags:
        if tag[-1] == "," or tag[-1] == "!":
            tag = tag[0:-1]
        if tag[-1] == "." and tag[-2] == "." and tag[-3] == ".":
            tag = tag[0:-3]
        if tag not in set1:
            result.append(tag)
            set1.add(tag)
    return result

input_text = "#Python, #fasm! #python #Logic #fasm..."
# Ожидаемый результат: ['#fasm', '#logic', '#python']
print(clean_hashtags(input_text))
