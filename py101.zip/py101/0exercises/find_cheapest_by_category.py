def find_cheapest_by_category(transactions):
    categories = {}
    for transaction in transactions:
        category = transaction[2]
        if category in categories:
            categories[category].append(transaction)
        else:
            categories[category] = [transaction]
    result = {}
    for key, value in categories.items():
        min_item = value[0]
        for item in value[1:]:
            if item[1] < min_item[1]:
                min_item = item
        result [key] = min_item[0]
    return result

# Исходные данные: (название, цена, категория)
transactions = [
    ("Apple", 120, "Fruit"),
    ("Banana", 80, "Fruit"),
    ("Tomato", 150, "Vegetable"),
    ("Potato", 40, "Vegetable"),
    ("Orange", 90, "Fruit")
]
result = find_cheapest_by_category(transactions)
print(result)# {'Fruit': 'Banana', 'Vegetable': 'Potato'}