def count_votes(votes):
    result = {}
    for vote in votes:
        if vote in result:
            result [vote] +=1
        else:
            result [vote] = 1
    return result

raw_votes = ["Иванов", "Петров", "Иванов", "Сидоров", "Петров", "Иванов"]
results = count_votes(raw_votes)
print(results)
# Ожидаемый вывод (порядок ключей может быть любым):
# {"Иванов": 3, "Петров": 2, "Сидоров": 1}

print(count_votes([]))
# Ожидаемый вывод: {}
