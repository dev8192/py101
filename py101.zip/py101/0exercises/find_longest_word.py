def find_longest_word(words):
    max_len = 0
    result = ''
    for word in words:
        if len(word) > max_len:
            max_len = len(word)
            result = word
    return result


word_list = ["cat", "dog", "elephant", "ant"]
result = find_longest_word(word_list)
print(f"Самое длинное слово: {result}")  # elephant

word_list_tie = ["apple", "pear", "grape"]
result_tie = find_longest_word(word_list_tie)
print(f"Самое длинное слово: {result_tie}")  # apple

empty_list = []
result_empty = find_longest_word(empty_list)
print(f"Самое длинное слово: '{result_empty}'")  # ''