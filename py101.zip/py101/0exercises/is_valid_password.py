def is_valid_password(password):
    if len(password) < 8:
        return False
    for ch in password:
        if ord(ch) >= 48 and ord(ch) <= 57:
            return True
    return False

print(is_valid_password("Python3")) # Ожидаемый результат: False
print(is_valid_password("LearningCode")) # Ожидаемый результат: False
print(is_valid_password("SecurePass2024")) # Ожидаемый результат: True
