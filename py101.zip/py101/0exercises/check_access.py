def check_access(user_input, pass_input, admin_user, admin_pass):
    return user_input == admin_user and pass_input == admin_pass

result1 = check_access("admin", "12345", "admin", "12345")
print(result1)  # True

result2 = check_access("admin", "00000", "admin", "12345")
print(result2)  # False

result3 = check_access("user", "12345", "admin", "12345")
print(result3)  # False
