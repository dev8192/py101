def unique_common_elements(list1, list2):
    result = []
    for item in list1:
        if item in list2 and item not in result:
            result.append(item)
    return result

nums_a = [1, 2, 2, 3, 4, 10, 5]
nums_b = [2, 2, 5, 6, 7, 10, 10]
result = unique_common_elements(nums_a, nums_b)
# [2, 5, 10]
print(result)
