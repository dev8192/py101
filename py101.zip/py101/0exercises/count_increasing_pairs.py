def count_increasing_pairs(numbers):
    count = 0
    for i in range(1, len(numbers)):
        if numbers[i-1] < numbers[i]:
            count += 1 
    return count 

data = [1, 5, 2, 4, 3]
# Пары: (1, 5) - да, (5, 2) - нет, (2, 4) - да, (4, 3) - нет
result = count_increasing_pairs(data)
print(result)  # 2

data_sorted = [1, 2, 3, 4]
result_sorted = count_increasing_pairs(data_sorted)
print(result_sorted)  # 3

data_short = [10]
result_short = count_increasing_pairs(data_short)
print(result_short)  # 0
