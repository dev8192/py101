def find_max_in_list(numbers):
    if len(numbers) == 0:
        return None 
    result = 0
    for num in numbers:
        if num > result:
            result = num
    return result 

result = find_max_in_list([3, 7, 2, 9, 1])
print(result)  # 9

result = find_max_in_list([])
print(result)  # None
