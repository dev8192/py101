def find_max_in_list(numbers):
    if len(numbers) == 0:
        return None 
    result = numbers[0]
    for num in numbers[1:]:
        if num > result:
            result = num
    return result

arr = [3, 7, 2, 9, 1]

def main():
    print('*** main1 ***')
    result = find_max_in_list(arr)
    print(result)  # 9

    result = find_max_in_list([])
    print(result)  # None

    result = find_max_in_list([-5, -10, -3])
    print(result)

def main2():
    print('*** main2 ***')
    print(arr[0])
    print(arr[1])
    print(arr[2])
    return

def main3():
    print('*** main3 ***')
    for i in range(0, len(arr)):
        print(arr[i])
    return

def main4():
    print('*** main4 ***')
    for item in arr:
        print(item)
    return

def main5():
    print('*** main5 ***')
    ebx = 0
    while ebx < len(arr):
        print(arr[ebx])
        ebx += 1
    return

main()
