def calculate_final_price(price, discount):
    if discount == 0:
        return price  
    if discount > 100:
        return 0
    return price - (price / 100 * discount)

result1 = calculate_final_price(1000, 20)
print(result1)  # 800.0

result2 = calculate_final_price(500, 150)
print(result2)  # 0

result3 = calculate_final_price(200, 0)
print(result3)  # 200.0
