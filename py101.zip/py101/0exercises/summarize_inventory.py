def summarize_inventory(items):
    result = {}
    for item in items: 
        if item[0] in result:
            result[item[0]] += item[1]
        else: 
            result[item[0]] = item[1]
    return result

data = [
    ("apple", 10), ("banana", 5), 
    ("apple", 3), ("pear", 8), 
    ("banana", -2)
]
# Ожидаемый результат: {'apple': 13, 'banana': 3, 'pear': 8}
result = summarize_inventory(data)
print(result)
