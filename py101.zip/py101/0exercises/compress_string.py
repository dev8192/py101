def compress_string(s):
    set1 = set()
    result = ""
    for ch in s:
        if ch not in set1:
            if ch != '_': 
                set1.add(ch)
            result += ch
    return result 
    
input_str = "AAABBCBBAAADD"
result = compress_string(input_str)
# Ожидаемый вывод: "ABCD"
print(result) 
print(compress_string("python_is_cool")) 
# Ожидаемый вывод: "python_is_cl"
