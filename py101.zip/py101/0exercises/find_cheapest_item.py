def find_cheapest_item(items):
    result = items[0]
    for item in items[1:]:
        if item["price"] < result["price"]:
            result = item
    return result["name"]

products = [
    {"name": "Apple", "price": 120},
    {"name": "Banana", "price": 80},
    {"name": "Orange", "price": 150},
    {"name": "Kiwi", "price": 80}
]
cheapest = find_cheapest_item(products)
# "Banana" (или "Kiwi")
print(cheapest)
