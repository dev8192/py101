def analyze_weather(temperatures, threshold):
    count = 0
    result = 0
    for temperature in temperatures:
        if temperature > threshold:
            count += 1
            result += temperature
    if count > 0:
        return result / count
    
weekly_temps = [18, 22, 15, 25, 12, 30, 21]
limit = 20
result = analyze_weather(weekly_temps, limit)
# Ожидаемый вывод:
# 24.5  (так как (22 + 25 + 30 + 21) / 4 = 24.5)
print(result)
print(analyze_weather([10, 5, 8], 20)) 
# Вывод: None