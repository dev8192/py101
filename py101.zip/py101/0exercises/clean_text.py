'''
          j
П J False 0
р J False 0
о J False 0
г J False 0
р J False 0
а J False 0
м J False 0
м J False 0
и J False 0
р J False 0
о J False 0
в J False 0
а J False 0
н J False 0
и J False 0
е J False 0
  J False 0
н J False 0
а J False 0
  J False 0
J J True  1   j < len(word) 
a a True  2   j < len(word)
v v True  3   j < len(word)
a a True  0   j < len(word)
'''

def replace_sensitive_word(text, word):
    word_idx = 0
    i = 0
    found = False
    while i < len(text):
        i2 = i
        for j in range(len(word)):
            ch1 = text[i2]
            i2 += 1
            ch2 = word[j]
            print(ch1, ch2)
            if (j + 1) == len(word):
                print('found')
                found = True
            if ch1 != ch2:
                i = i2
                break
        if found:
            word_idx = i
            break
    list1 = list(text)
    for i in range(len(word)):
        list1[word_idx + i] = '*'
    return ''.join(list1)

def clean_text(text, sensitive_words):
    for word in sensitive_words:
    # for word in sensitive_words[1:]:
        text = replace_sensitive_word(text, word)
    return text

original_text = "Программирование на Java это почти как на Python но чуть сложнее."
blacklist = ["Java", "сложнее"]
# Вызов функции
result = clean_text(original_text, blacklist)
print(result) 
# Ожидаемый вывод: "Программирование на **** это почти как на Python но чуть *******"
