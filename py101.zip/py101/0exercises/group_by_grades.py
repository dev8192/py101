def group_by_grades(results):
    result_2 = {}
    for result in results:
        key = results[result]
        if key in result_2:
            result_2[key].append(result)
        else:
            result_2[key] = [result]
    return result_2

exam_results = {
    "Alice": 5,
    "Bob": 4,
    "Charlie": 5,
    "David": 3,
    "Eve": 4
}
grouped = group_by_grades(exam_results)
# Ожидаемый результат (порядок ключей не важен):
# {
#   5: ['Alice', 'Charlie'],
#   4: ['Bob', 'Eve'],
#   3: ['David']
# }
print(grouped)
