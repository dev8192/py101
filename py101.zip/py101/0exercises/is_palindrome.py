def is_palindrome(word):
    word = word.lower()
    word1 = ""
    for i in range(len(word) -1, -1, -1): #От, до, шаг
        word1 += word[i]
    return word == word1
    # return word == word[::-1] #в одну строку задача (ответ)
    
print(is_palindrome("Racecar")) # Ожидаемый вывод: True
print(is_palindrome("Python")) # Ожидаемый вывод: False