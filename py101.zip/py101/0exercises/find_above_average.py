def find_above_average(numbers):
    # average = 0
    # for number in numbers:
    #     average += number 
    # average = average / len(numbers)
    average = sum(numbers) / len(numbers)
    result = []
    for number in numbers:
        if number > average:
            result.append(number)
    return result    

numbers = [10, 20, 30, 40, 50]
# Среднее арифметическое здесь: (10+20+30+40+50) / 5 = 30
result = find_above_average(numbers)
print(result) 
# Ожидаемый вывод: [40, 50]