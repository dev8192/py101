def update_inventory(current_stock, sold_items):
    for item in sales:
        current_stock[item] -= 1
        if  current_stock[item] == 0:
            del current_stock[item]
    return current_stock

inventory = {
    'laptop': 5,
    'mouse': 3,
    'keyboard': 1
}
sales = ['laptop', 'mouse', 'laptop', 'keyboard']
updated_stock = update_inventory(inventory, sales)
print(updated_stock)
# Ожидаемый вывод: {'laptop': 3, 'mouse': 2}
# (keyboard удален, так как остаток стал 0)
