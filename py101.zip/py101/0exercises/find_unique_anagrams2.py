word1 = "Lemon" 
word2 = "melon"
word1 = "".join(sorted([*word1.lower()]))
word2 = "".join(sorted([*word2.lower()]))
print(word1 == word2)

