def create_username(name, surname):
    return name[0] + surname + str(len(name))

user1 = create_username("Alex", "Smith")
print(user1)  # "ASmith4"

user2 = create_username("Anna", "Karpova")
print(user2)  # "AKarpova4"

user3 = create_username("Ivan", "Petrov")
print(user3)  # "IPetrov4"
