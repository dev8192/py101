def validate_serials(serials):
    result = []
    for item in serials:
        prefix, id = item.split('-')
        if prefix.lower() == 'id' and len(id) == 5:
            result.append(prefix + '-' + id.upper())
    return result

batch = ["ID-12345", "id-99999", "REF-1000", "ID-zxcvb", "ID-77", "smart-id"]
valid_codes = validate_serials(batch)
print(valid_codes)
# Ожидаемый вывод:
# ['ID-12345', 'ID-99999', 'ID-ZXCVB']
# (Пояснение: "REF-1000" — не тот префикс, "ID-77" — слишком короткий)
