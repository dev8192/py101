def final_score(scores):
    max1 = max(scores)
    min1 = min(scores)
    result = 0
    if len(scores) == 2:
        return 0.0
    for num in scores:
        if num == max1 or num == min1:
            continue
        result += num
    return result / (len(scores) - 2)

judges_marks = [8.5, 9.0, 7.0, 10.0, 9.5]
result = final_score(judges_marks)

# Ожидаемый результат: 9.0 
# (Убираем 7.0 и 10.0, среднее от 8.5, 9.0 и 9.5 равно 9.0)
print(f"Итоговый балл: {result}")

# Пример с коротким списком:
print(final_score([10.0, 5.0])) # Выведет: 0.0
