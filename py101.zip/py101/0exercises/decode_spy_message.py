def decode_spy_message():
    result = ""
    checksum = 0
    for ch in input_text:
        if ord(ch) < ord("0") or ord(ch) > ord("9"):
            result += ch
        else:
            checksum += int(ch)
    return result, checksum

input_text = "H3ello Pyt2hon 1Is Awe5some"
result_text, checksum = decode_spy_message()
print(result_text) # Должно вывести: "Hello Python Is Awesome"
print(checksum) # Должно вывести: 11 (потому что 3 + 2 + 1 + 5 = 11)
