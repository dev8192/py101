def summarize_inventory(items):
    result = {}
    for item  in items:
        for name, quantity in item.items():
            if name in result:
                result[name] += quantity
            else: 
                result[name] = quantity
    return result

data = [
    {"apple": 10}, {"banana": 5}, 
    {"apple": 3}, {"pear": 8}, 
    {"banana": -2}
]
# Ожидаемый результат: {'apple': 13, 'banana': 3, 'pear': 8}
result = summarize_inventory(data)
print(result)
