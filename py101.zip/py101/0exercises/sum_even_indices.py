def sum_even_indices(numbers):
    sum_num = 0 
    for i in range(0, len(numbers), 2): 
        sum_num += numbers[i]
    return sum_num

data = [10, 20, 30, 40, 50]
# Индексы:   0   1   2   3   4
# Четные индексы: 0 (10), 2 (30), 4 (50)
result = sum_even_indices(data)
print(f"Сумма на четных позициях: {result}")  # 90

data_short = [5, 100]
# Индексы:   0   1
# Четные индексы: 0 (5)
result_short = sum_even_indices(data_short)
print(f"Сумма на четных позициях: {result_short}")  # 5

data_empty = []
result_empty = sum_even_indices(data_empty)
print(f"Сумма на четных позициях: {result_empty}")  # 0