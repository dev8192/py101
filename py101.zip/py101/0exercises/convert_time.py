def convert_time(total_minutes):
    hours = total_minutes // 60 
    mins = total_minutes % 60
    #return str(hours) + " ч " + str(mins) + " мин" 
    return f"{hours} ч {mins} мин"

result1 = convert_time(65)
print(result1)  # "1 ч 5 мин"

result2 = convert_time(120)
print(result2)  # "2 ч 0 мин"

result3 = convert_time(45)
print(result3)  # "0 ч 45 мин"
