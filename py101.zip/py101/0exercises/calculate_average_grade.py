def calculate_average_grade(grades):
    result = 0
    for grade in grades:
        result += grade[1]
    return result / len(grades)

student_grades = [
    ("Математика", 85),
    ("Программирование", 92),
    ("Физика", 78),
    ("Английский", 95)
]
average = calculate_average_grade(student_grades)
# 87.5
print(f"Средний балл: {average}")
