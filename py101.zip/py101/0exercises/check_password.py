def check_password(password):
    if len(password) < 8:
        return False
    has_lowercase = False
    has_uppercase = False
    has_digits = False
    has_special = False
    for ch in password:
        if ord(ch) >= 97 and ord(ch) <= 122:
            has_lowercase = True
        if ord(ch) >= 65 and ord(ch) <= 90:
            has_uppercase = True
        if ord(ch) >= 48 and ord(ch) <= 57:
            has_digits = True
        if ch in ['!', '@', '#', '$', '%']:
            has_special = True
    return has_lowercase and has_uppercase and has_digits and has_special

print(check_password("Python123!"))  
# Ожидаемый результат: True
print(check_password("qwerty"))       
# Ожидаемый результат: False (короткий, нет цифр/спецсимволов)
print(check_password("L0ngPassword")) 
# Ожидаемый результат: False (нет спецсимвола)
