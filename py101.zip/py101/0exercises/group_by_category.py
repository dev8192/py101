def group_by_category(items):
    result = {}
    for item in items:
        product, category = item.split(":")
        if category in result:
            result[category].append(product)
        else:
            result[category] = [product]
    return result

data = [
    "Яблоко:Фрукты",
    "Огурец:Овощи",
    "Банан:Фрукты",
    "Помидор:Овощи",
    "Груша:Фрукты"
]
inventory = group_by_category(data)
# {
#     'Фрукты': ['Яблоко', 'Банан', 'Груша'],
#     'Овощи': ['Огурец', 'Помидор']
# }
print(inventory)
