def multiply_list_elements(lst):
    result = []
    for num in lst:
        result.append(num * 2)
    return result

result = multiply_list_elements([1, 2, 3, 4])
print(result)  # [2, 4, 6, 8]
