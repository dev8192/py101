# def = define
def multiply_list_elements(lst):
    result = []
    for num in lst:
        # result.append(num * 2)
        result.append(num << 3)
    return result

arr1 = [11, 22, 33, 44]

def main():
    print('*** main1 ***')
    result = multiply_list_elements(arr1)
    print(result)

def main2():
    print('*** main2 ***')
    print(arr1[0])
    print(arr1[-1])

def main3():
    print('*** main3 ***')
    ebx = 0
    while ebx < len(arr1):
        print(arr1[ebx])
        ebx += 1

main()
