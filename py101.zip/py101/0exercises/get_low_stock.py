def get_low_stock(inventory, threshold):
    result = []
    for item in inventory:
        if inventory[item] < threshold:
            result.append(item)
    return result

stocks = {
    "яблоки": 50,
    "бананы": 12,
    "апельсины": 8,
    "груши": 25,
    "киви": 3
}

# Ищем товары, которых осталось меньше 15 штук
result = get_low_stock(stocks, 15)

print(result) 
# Ожидаемый вывод: ['апельсины', 'бананы', 'киви']
