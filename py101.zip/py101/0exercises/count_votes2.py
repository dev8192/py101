def count_votes(votes):
    result = {}
    for vote in votes:
        if vote in result:
            result [vote] +=1
        else:
            result [vote] = 1
    return result

raw_votes = ["Иванов", "Петров", "Иванов", "Сидоров", "Петров", "Иванов"]
# raw_votes.append("Сидоров")
# raw_votes = raw_votes[:-2] + raw_votes[-2:]

def remove_vote(votes, name_param):
    result = []
    flag = True
    for name in votes:
        if name == name_param:
            if flag:
                flag = False
                result.append(name)
        else:
            result.append(name)
    return result

raw_votes = remove_vote(raw_votes, "Петров")

# TODO: Make it work
# raw_votes = remove_vote(raw_votes, "Сидоров")

results = count_votes(raw_votes)

# results["Петров"] = 1
print(results)
# Ожидаемый вывод (порядок ключей может быть любым):
# {"Иванов": 3, "Петров": 2, "Сидоров": 1}

print(count_votes([]))
# Ожидаемый вывод: {}
