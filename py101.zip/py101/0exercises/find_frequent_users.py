def find_frequent_users(user_ids, threshold):
    user_freq = {}
    result = []
    for user_id in user_ids:
        if user_id in user_freq:
            user_freq[user_id] += 1
        else:
            user_freq[user_id] = 1
    for key, val in user_freq.items():
        if val > threshold:
            result.append(key)
    return result





logs = [101, 102, 101, 105, 102, 101, 110, 105]
result = find_frequent_users(logs, 2)
print(result) 
# Ожидаемый вывод: [101] (так как он встретился 3 раза)
result_2 = find_frequent_users(logs, 1)
print(result_2)
# Ожидаемый вывод: [101, 102, 105]

