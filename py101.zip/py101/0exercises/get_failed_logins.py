def get_failed_logins(raw_logs):
    result = set()
    for name in raw_logs:
        name = name.split(':')
        if name[1] == 'failed':
            result.add(name[0])

    return list(result)

raw_logs = [
    "alice:success",
    "bob:failed",
    "charlie:success",
    "bob:failed",
    "billy:failed",
    "alice:failed"
]

failed_users = get_failed_logins(raw_logs)

print(failed_users)
# Ожидаемый вывод (порядок имен не важен): ['bob', 'billy', 'alice']
