start = 0
end = 1
str1 = 'popcatdad'
end += 1
end += 1
print(str1[start:end])
start += 6
end += 7
print(str1[start:end])
