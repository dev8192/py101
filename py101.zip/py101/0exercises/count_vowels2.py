def count_vowels(text):
    result = {}
    for ch in text:
        if ch == "e" or ch == "o":
            if ch in result:
                result[ch] += 1
            else:
                result[ch] = 1
    return result
            
text = "Hello Python World"
result = count_vowels(text)
# {'e': 1, 'o': 3}
print(result) 
