def check_message(message, keywords):
    message = message.lower()
    for keyword in keywords:
        if keyword in message:
            return False
    return True    

def filter_messages(messages, keywords):
    clean_chat = []
    for message in messages:
        if check_message(message, keywords):
            clean_chat.append(message)
    return clean_chat

chat_history = [
    "Всем привет! Как дела?",
    "Куплю гараж, срочно, цена договорная",
    "Продам биткоины, обучение бесплатно",
    "Сегодня отличная погода для программирования",
    "СРОЧНО: Распродажа курсов!"
]
blacklist = ["куплю", "продам", "распродажа"]
clean_chat = filter_messages(chat_history, blacklist)
print(clean_chat)
# Ожидаемый вывод:
# ["Всем привет! Как дела?", "Сегодня отличная погода для программирования"]
