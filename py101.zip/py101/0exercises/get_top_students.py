def get_top_students(students):
    result = []
    for item in students:
        num_sum = sum(item["grades"]) / len(item["grades"])
        if num_sum >= 4.5:
            result.append(item["name"])
    return result   

data = [
    {"name": "Алексей", "grades": [5, 5, 4, 5]},
    {"name": "Мария", "grades": [3, 4, 4, 5]},
    {"name": "Иван", "grades": [5, 5, 5, 5]},
    {"name": "Ольга", "grades": [4, 3, 3, 4]}
]
result = get_top_students(data)
print(result) 
# Ожидаемый вывод: ['Алексей', 'Иван']
