def is_safe_password(password):
    has_digits = False 
    has_letters = False
    for ch in password:
        if ord(ch) >= ord("0") and ord(ch) <= ord("9"):
            has_digits = True
        if ord(ch) >= ord("a") and ord(ch) <= ord("z"):
            has_letters = True 
        if ord(ch) >= ord("A") and ord(ch) <= ord("Z"):
            has_letters = True
    return has_digits and has_letters
            
passwords = ["12345", "StrongPass", "Qwerty123", "onlyletters"]
for p in passwords:
    result = is_safe_password(p)
    print(f"Пароль '{p}': {result}")
# Ожидаемый вывод:
# Пароль '12345': False
# Пароль 'StrongPass': False (нет цифр)
# Пароль 'Qwerty123': True
# Пароль 'onlyletters': False
