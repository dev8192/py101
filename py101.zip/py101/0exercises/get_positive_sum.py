def get_positive_sum(numbers):
    result = 0
    for num in numbers:
        if num > 0:
            result += num
    return result

data = [1, -5, 3, 0, 10, -2]
result = get_positive_sum(data)
print(f"Сумма положительных: {result}")  # 14

data_empty = [-1, -10, 0]
result_empty = get_positive_sum(data_empty)
print(f"Сумма положительных: {result_empty}")  # 0
