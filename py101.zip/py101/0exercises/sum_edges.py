def sum_edges(numbers):
    return numbers[0] + numbers[-1]

result1 = sum_edges([1, 2, 3, 4, 5])
print(result1)  # 6 (1 + 5)

result2 = sum_edges([10])
print(result2)  # 20 (10 + 10)

result3 = sum_edges([-5, 0, 5])
print(result3)  # 0 (-5 + 5)