def main1():
    num1 = 1
    print(num1 << 1)    # 2
    print(num1 << 2)    # 4
    print(num1 << 3)    # 8
    print(num1 << 4)    # 16
    print(num1 << 5)    # 32

#      1
#     10
#    100
#   1000
#  10000
# 100000
def main2():
    num1 = 1
    print(bin(num1 << 1))    # 2
    print(bin(num1 << 2))    # 4
    print(bin(num1 << 3))    # 8
    print(bin(num1 << 4))    # 16
    print(bin(num1 << 5))    # 32

def main():
    num1 = 32
    print(num1 >> 1)
    print(num1 >> 2)
    print(num1 >> 3)
    print(num1 >> 4)
    print(num1 >> 5)

main()
