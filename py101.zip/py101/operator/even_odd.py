'''
    % - modulo (remainder)
'''

def test():
    print(5 % 2)
    print(6 % 2)

def test1():
    i = int(input("Введите число: "))
    if i % 2 == 0:
        print("Число четное")
    else:
        print("Число нечетное")

test()
