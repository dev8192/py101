def calculate_calories(food_db, order):
    result = 0
    for item in order:
        product, qty = item.split(":")
        if product in food_db:
            result += food_db[product] * (int(qty) / 100)
    return result

calories_map = {
    "apple": 52,
    "bread": 250,
    "cheese": 402,
    "chicken": 165
}
my_order = ["apple:200", "bread:50", "cheese:30", "milk:200"]
total = calculate_calories(calories_map, my_order)
# (52*2) + (250*0.5) + (402*0.3) + 0
print(f"Общая калорийность: {total}") # 349.6
