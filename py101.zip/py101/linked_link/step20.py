'''
Deleting nodes
Add print_list_reverse()
'''

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
        self.prev = None

def print_list(node):
    print('*' * 30)
    print(node.data)
    while node.next != None:
        node = node.next
        print(node.data)
    
def print_list_reverse(node):
    print('*' * 30)
    print(node.data)
    while node.prev != None:
        node = node.prev
        print(node.data)

node1 = Node('apple')

node2 = Node('orange')
node2.prev = node1
node1.next = node2

node3 = Node('kiwi')
node3.prev = node2
node2.next = node3

node4 = Node('mango')
node4.prev = node3
node3.next = node4

print_list(node1)
print_list_reverse(node4)

# delete 'kiwi'
node2.next = node4
node4.prev = node2

print_list(node1)
print_list_reverse(node4)
