'''
Add LinkedList class
'''

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
        self.prev = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def add(self, data):
        if self.head == None:
            self.head = Node(data)
            self.tail = self.head
        else:
            node = Node(data)
            node.prev = self.tail
            self.tail.next = node
            self.tail = node
    
    def add_many(self, *args):
        for elem in args:
            self.add(elem)
    
    def delete(self, data):
        node = self.head
        while node.next != None:
            node = node.next
            if node.data == data:
                break
        node.prev.next = node.next
        node.next.prev = node.prev

    def print(self):
        print('*' * 30)
        node = self.head
        print(node.data)
        while node.next != None:
            node = node.next
            print(node.data)

    def print_reverse(self):
        print('*' * 30)
        node = self.tail
        print(node.data)
        while node.prev != None:
            node = node.prev
            print(node.data)


list = LinkedList()
# list.add('one')
# list.add('two')
# list.add('three')
# list.add('four')
list.add_many('one', 'two', 'three', 'four')

list.print()
list.print_reverse()

list.delete('three')
list.print()
list.print_reverse()
