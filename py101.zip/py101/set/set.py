def test1():
    str1 = 'aabbc'
    set1 = set()
    for ch in str1:
        set1.add(ch)
    print(set1)

def test2():
    set1 = set('aabbc')
    print(set1)
    print('a' in set1)
    print('f' in set1)

def test():
    set1 = set('aabbc')
    print(set1)
    print(list(set1))

test()
