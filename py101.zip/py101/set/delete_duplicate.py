def delete_duplicate(arr):
    new_arr = []
    set1 = set()
    for item in arr:
        if item in set1:
            continue
        set1.add(item)
        new_arr.append(item)
    return new_arr
        

print(delete_duplicate([1, 2, 2, 3, 4, 4, 5]))
print(delete_duplicate([10, 10, 10, 10, 10]))
print(delete_duplicate([]))
