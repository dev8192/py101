import hashlib

def test():
    bytes = bytearray('hello123', 'utf8')
    result = hashlib.sha1(bytes).hexdigest()
    print(result)
    print(result == '4233137d1c510f2e55ba5cb220b864b11033f156')

def test2():
    m = hashlib.sha1(b"hello123")
    result = m.hexdigest()
    print(result == '4233137d1c510f2e55ba5cb220b864b11033f156')

def test3():
    m = hashlib.sha1()
    m.update(b"hello123")
    result = m.hexdigest()
    print(result == '4233137d1c510f2e55ba5cb220b864b11033f156')

test()
