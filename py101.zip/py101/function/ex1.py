def print_fruits1(fruits):
    print(fruits)

def print_fruits1(fruits):
    print(fruits[0])
    print(fruits[1])
    print(fruits[2])

def print_fruits1(fruits):
    for item in fruits:
        print(item)

def print_fruits1(fruits):
    for i in range(4):
        print(fruits[i])

def print_fruits(fruits):
    for i in range(len(fruits)):
        print(fruits[i])

fruits = ['pineapple', 'orange', 'kiwi', 'banana']
print_fruits(fruits)



