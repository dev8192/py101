'''
    snake_case
    camelCase
    kebab-case
'''

def print_hello(name): # name is a parameter
    print("hello " + name)

print_hello("John") # "John" is an argument
print_hello("Jane") # "Jane" is an argument
