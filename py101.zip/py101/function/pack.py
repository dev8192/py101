def print_fruits(*arr):
    print(arr)

print_fruits('apple', 'orange', 'banana')
