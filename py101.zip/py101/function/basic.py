'''
    snake_case
    camelCase
    kebab-case
'''

def print_hello():
    print("hello")

print_hello()
