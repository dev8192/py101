def get_multiple_values():
    a = 123
    b = 456
    return a, b

result = get_multiple_values()
print(result)

a, b = get_multiple_values()
print(a, b)
